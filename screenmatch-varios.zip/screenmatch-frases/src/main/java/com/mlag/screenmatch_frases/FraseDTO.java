package com.mlag.screenmatch_frases;

public record FraseDTO(String titulo,
    String frase,
    String personaje,
    String poster) {
}
