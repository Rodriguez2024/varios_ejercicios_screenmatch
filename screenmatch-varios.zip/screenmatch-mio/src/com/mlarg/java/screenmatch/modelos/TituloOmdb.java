package com.mlarg.java.screenmatch.modelos;

public record TituloOmdb(String title, String year, String runtime) {
}
