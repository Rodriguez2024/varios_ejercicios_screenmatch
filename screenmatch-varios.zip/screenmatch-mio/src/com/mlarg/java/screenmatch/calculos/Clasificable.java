package com.mlarg.java.screenmatch.calculos;

public interface Clasificable {
    int getClasificacion();
}
