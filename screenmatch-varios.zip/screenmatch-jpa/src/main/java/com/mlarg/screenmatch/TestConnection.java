package com.mlarg.screenmatch;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestConnection {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/mlag_series";

        String username = "postgres";
        String password = "admin";

        try (Connection connection = DriverManager.getConnection("postgresql://postgres:admin@host:5432/mlag_series")) {
            System.out.println("Connection successful!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
