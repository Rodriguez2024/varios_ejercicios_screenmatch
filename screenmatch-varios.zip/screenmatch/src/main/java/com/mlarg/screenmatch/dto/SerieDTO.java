package com.mlarg.screenmatch.dto;

import com.mlarg.screenmatch.model.Categoria;

public record SerieDTO(Long id,
     String titulo,
     Integer totalTemporadas,
     Double evaluacion,
     String poster,
     Categoria genero,
     String actores,
     String sinopsis) {
}

